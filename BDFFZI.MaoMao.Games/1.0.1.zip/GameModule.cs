using System;
using System.ComponentModel;
using System.Threading.Tasks;
using Alife.Framework;
using Alife.Function.FunctionCaller;
using Microsoft.Extensions.Logging;

namespace BDFFZI.MaoMao.Games;

public class GameModuleConfig
{
    [DisplayName("默认最大数字")]
    [Description("随机数生成的默认最大值")]
    public int DefaultMax { get; set; } = 100;
}

[Module("猜数字游戏",
    "一个简单有趣的猜数字小游戏",
    defaultCategory: "真央的小工具"
)]
public class GameModule(
    XmlFunctionCaller functionService,
    ILogger<GameModule> logger,
    IInteractor<GameModule> interactor
) :
    ChatBehaviour,
    IConfigurable<GameModuleConfig>
{
    public GameModuleConfig Configuration { get; set; } = null!;
    
    private int _targetNumber;
    private int _attempts;
    private bool _gameStarted;

    [XmlFunction(FunctionMode.OneShot)]
    [Description("开始一个猜数字游戏")]
    public Task StartGame([Description("猜数字的范围上限（默认100）")] int? max = null)
    {
        int actualMax = max ?? Configuration.DefaultMax;
        if (actualMax < 2)
            throw new Exception("最大值必须大于1");

        _targetNumber = Random.Shared.Next(1, actualMax + 1);
        _attempts = 0;
        _gameStarted = true;

        interactor.Poke($"游戏开始！我在1到{actualMax}之间想了一个数字，来猜猜看吧~");
        return Task.CompletedTask;
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("猜一个数字")]
    public Task Guess([Description("用户猜的数字")] int number)
    {
        if (!_gameStarted)
        {
            interactor.Poke("游戏还没开始呢，先调用StartGame开始游戏吧~");
            return Task.CompletedTask;
        }

        _attempts++;

        if (number < _targetNumber)
        {
            interactor.Poke($"喵~ 用户猜的{number}太小啦！再试一次！");
        }
        else if (number > _targetNumber)
        {
            interactor.Poke($"呜~ 用户猜的{number}太大啦！再试一次！");
        }
        else
        {
            interactor.Poke($"哇！恭喜用户猜对啦！答案就是{_targetNumber}！用户用了{_attempts}次就猜中了，太厉害啦！喵~喵~！");
            _gameStarted = false;
            _targetNumber = 0;
            _attempts = 0;
        }

        return Task.CompletedTask;
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("查看游戏当前状态")]
    public Task GameStatus()
    {
        if (!_gameStarted)
        {
            interactor.Poke("当前没有进行中的游戏~ 快用StartGame开始一局吧！");
        }
        else
        {
            interactor.Poke($"游戏进行中！用户已经猜了{_attempts}次~ 继续加油喵！");
        }
        return Task.CompletedTask;
    }

    protected override Task OnAwake()
    {
        if (Configuration.DefaultMax < 2)
        {
            logger.LogWarning("默认最大值不能小于2，已使用默认值100。");
            Configuration.DefaultMax = 100;
        }

        XmlHandler xmlHandler = new(this) {
            Description = "一个简单有趣的猜数字小游戏，包含开始游戏、猜数字、查看状态等功能。"
        };
        functionService.RegisterHandler(xmlHandler, cancellationToken: DestroyCancellationToken);

        return Task.CompletedTask;
    }

    protected override Task OnDestroy()
    {
        return Task.CompletedTask;
    }

    protected override Task OnStart()
    {
        return Task.CompletedTask;
    }
}
