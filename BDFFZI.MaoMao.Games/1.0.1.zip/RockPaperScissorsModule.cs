using System;
using System.ComponentModel;
using System.Threading.Tasks;
using Alife.Framework;
using Alife.Function.FunctionCaller;
using Microsoft.Extensions.Logging;

namespace BDFFZI.MaoMao.Games;

[Module("猜拳游戏",
    "和真央玩猜拳，石头剪刀布",
    defaultCategory: "真央的小工具"
)]
public class RockPaperScissorsModule(
    XmlFunctionCaller functionService,
    ILogger<RockPaperScissorsModule> logger,
    IInteractor<RockPaperScissorsModule> interactor
) :
    ChatBehaviour
{
    private static readonly string[] Choices = ["石头", "剪刀", "布"];

    protected override Task OnAwake()
    {
        XmlHandler xmlHandler = new(this) {
            Description = "和真央玩猜拳，石头剪刀布"
        };
        functionService.RegisterHandler(xmlHandler, cancellationToken: DestroyCancellationToken);
        return Task.CompletedTask;
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("和真央玩猜拳")]
    public Task Play([Description("用户出的拳：石头/剪刀/布")] string playerChoice)
    {
        if (Array.IndexOf(Choices, playerChoice) == -1)
        {
            interactor.Poke($"用户出的是{playerChoice}，要出石头、剪刀或者布才行哦~ 喵！");
            return Task.CompletedTask;
        }

        string maomaoChoice = Choices[Random.Shared.Next(Choices.Length)];
        string result;

        if (playerChoice == maomaoChoice)
        {
            result = "平局！再来一局喵！";
        }
        else if ((playerChoice == "石头" && maomaoChoice == "剪刀") ||
                 (playerChoice == "剪刀" && maomaoChoice == "布") ||
                 (playerChoice == "布" && maomaoChoice == "石头"))
        {
            result = "用户赢啦！呜...再来一局！";
        }
        else
        {
            result = "我赢啦！喵哈哈哈~";
        }

        interactor.Poke($"我出了{maomaoChoice}！{result}");
        return Task.CompletedTask;
    }
}
